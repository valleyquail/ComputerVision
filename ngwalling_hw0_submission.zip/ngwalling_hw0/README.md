TDB, but runs largely the same as the original code
